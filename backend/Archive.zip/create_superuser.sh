# get into venv
python manage.py createsuperuser

