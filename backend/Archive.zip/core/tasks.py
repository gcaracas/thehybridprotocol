from celery import shared_task
from django.utils import timezone
from django.conf import settings
from .models import Newsletter, EmailSignup, EmailLog
from .email_providers import get_email_provider
from .utils.email import render_newsletter_email


@shared_task(bind=True, max_retries=3, default_retry_delay=30)
def send_newsletter_task(self, send_key: str, batch_size: int = 500):
    """
    Send newsletter to all subscribed recipients
    
    Args:
        send_key: Newsletter send key for idempotency
        batch_size: Number of emails to send per batch
    """
    try:
        # Fetch newsletter by send_key
        try:
            newsletter = Newsletter.objects.get(send_key=send_key)
        except Newsletter.DoesNotExist:
            print(f"Newsletter with send_key {send_key} not found")
            return
        
        # Check if already sent (idempotency)
        if newsletter.sent_at:
            print(f"Newsletter {send_key} already sent at {newsletter.sent_at}")
            return
        
        # Get email provider
        provider = get_email_provider()
        
        # Get all subscribed, non-bounced recipients
        recipients = EmailSignup.objects.filter(
            is_subscribed=True,
            bounce=False,
            is_active=True
        )
        
        total_recipients = recipients.count()
        print(f"Starting to send newsletter '{newsletter.title}' to {total_recipients} recipients")
        
        sent_count = 0
        failed_count = 0
        
        # Process in batches
        for i in range(0, total_recipients, batch_size):
            batch = recipients[i:i + batch_size]
            
            for recipient in batch:
                try:
                    # Check if already logged (avoid duplicates)
                    if EmailLog.objects.filter(newsletter=newsletter, recipient=recipient).exists():
                        continue
                    
                    # Render email content
                    html_content, text_content = render_newsletter_email(newsletter, recipient)
                    
                    # Send email
                    provider_message_id = provider.send(
                        to=recipient.email,
                        subject=newsletter.subject,
                        html=html_content,
                        text=text_content
                    )
                    
                    # Log success
                    EmailLog.objects.create(
                        newsletter=newsletter,
                        recipient=recipient,
                        status='sent',
                        provider_message_id=provider_message_id
                    )
                    
                    sent_count += 1
                    
                except Exception as e:
                    # Log failure
                    EmailLog.objects.create(
                        newsletter=newsletter,
                        recipient=recipient,
                        status='failed',
                        error=str(e)
                    )
                    failed_count += 1
                    print(f"Failed to send to {recipient.email}: {e}")
            
            # Progress update
            print(f"Processed batch {i//batch_size + 1}: {sent_count} sent, {failed_count} failed")
        
        # Mark newsletter as sent
        newsletter.sent_at = timezone.now()
        newsletter.save()
        
        print(f"Newsletter sending completed: {sent_count} sent, {failed_count} failed")
        
    except Exception as e:
        print(f"Newsletter sending failed: {e}")
        # Retry the task
        raise self.retry(exc=e)


@shared_task(bind=True, max_retries=3, default_retry_delay=30)
def send_test_newsletter_task(self, newsletter_id: int, test_email: str):
    """
    Send test newsletter to a single email address
    
    Args:
        newsletter_id: Newsletter ID
        test_email: Test recipient email
    """
    try:
        # Fetch newsletter
        try:
            newsletter = Newsletter.objects.get(id=newsletter_id)
        except Newsletter.DoesNotExist:
            print(f"Newsletter with ID {newsletter_id} not found")
            return
        
        # Get email provider
        provider = get_email_provider()
        
        # Create or get test recipient
        recipient, created = EmailSignup.objects.get_or_create(
            email=test_email,
            defaults={
                'first_name': 'Test',
                'last_name': 'User',
                'source': 'test'
            }
        )
        
        # Render email content
        html_content, text_content = render_newsletter_email(newsletter, recipient)
        
        # Send email
        provider_message_id = provider.send(
            to=recipient.email,
            subject=f"[TEST] {newsletter.subject}",
            html=html_content,
            text=text_content
        )
        
        print(f"Test email sent to {test_email} with message ID: {provider_message_id}")
        
    except Exception as e:
        print(f"Test newsletter sending failed: {e}")
        raise self.retry(exc=e) 