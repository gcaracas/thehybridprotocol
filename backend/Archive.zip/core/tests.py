# Import all tests for discovery
from .test_models import *
from .test_serializers import *
from .test_api import *
from .test_management_commands import *
