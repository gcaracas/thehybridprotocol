from abc import ABC, abstractmethod
from typing import Optional


class EmailProvider(ABC):
    """Base class for email providers"""
    
    @abstractmethod
    def send(self, to: str, subject: str, html: str, text: str) -> Optional[str]:
        """
        Send an email
        
        Args:
            to: Recipient email address
            subject: Email subject
            html: HTML content
            text: Plain text content
            
        Returns:
            Provider message ID if successful, None if failed
        """
        pass 