from django.conf import settings
from postmarker.core import PostmarkClient
from .base import EmailProvider


class PostmarkProvider(EmailProvider):
    """Postmark email provider implementation"""
    
    def __init__(self):
        self.client = PostmarkClient(server_token=settings.EMAIL_API_KEY)
        self.from_email = settings.EMAIL_FROM
    
    def send(self, to: str, subject: str, html: str, text: str) -> str:
        """
        Send email via Postmark
        
        Args:
            to: Recipient email address
            subject: Email subject
            html: HTML content
            text: Plain text content
            
        Returns:
            Postmark message ID
        """
        try:
            response = self.client.emails.send(
                From=self.from_email,
                To=to,
                Subject=subject,
                HtmlBody=html,
                TextBody=text,
                MessageStream='outbound'
            )
            return response['MessageID']
        except Exception as e:
            # Log the error but don't raise it to allow for retries
            print(f"Postmark send error: {e}")
            return None 